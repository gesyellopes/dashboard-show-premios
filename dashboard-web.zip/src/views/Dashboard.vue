<script setup>
import { computed, onMounted, ref } from "vue";
import MiniStatisticsCard from "@/examples/Cards/MiniStatisticsCard.vue";
import GradientLineChart from "@/examples/Charts/GradientLineChart.vue";
import api from "@/services/api";
//import Carousel from "./components/Carousel.vue";
//import CategoriesList from "./components/CategoriesList.vue";

const TICKET_VALUE = Number(process.env.VUE_APP_TICKET_VALUE);

const sales = ref([]);

const validationReport = ref([]);
const kpisLoading = ref(true);
const kpis = ref({
  total_vendors: 0,
  total_tickets: 0,
  total_validated_tickets: 0,
  total_fianncial: 0,
  verifiedPercent: 0,
});

const formatCurrency = (value) =>
  new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value ?? 0);

const kpiValues = computed(() => ({
  totalTickets: kpis.value.total_tickets,
  totalValidatedTickets: kpis.value.total_validated_tickets,
  totalVendors: kpis.value.total_vendors,
  totalFinancial: formatCurrency(kpis.value.total_fianncial),
  verifiedPercent: kpis.value.verifiedPercent
}));

/*
const salesTotals = computed(() => {
  const totalTickets = sales.value.reduce((sum, sale) => sum + sale.tickets, 0);
  const totalVerified = sales.value.reduce((sum, sale) => sum + sale.verified, 0);
  const totalVendors = sales.value.reduce((sum, sale) => sum + sale.vendors, 0);
  const verifiedPercent = totalTickets > 0 ? ((totalVerified / totalTickets) * 100).toFixed(2) : "0.00";

  return { totalTickets, totalVerified, verifiedPercent, totalVendors };
});
*/

const loadKpis = async () => {
  kpisLoading.value = true;
  try {
    const { data } = await api.get("/report/kpis");

    if (data) {
      Object.assign(kpis.value, data);
    }

    kpis.value.verifiedPercent = kpis.value.total_tickets
      ? (
        (kpis.value.total_validated_tickets / kpis.value.total_tickets) *
        100
      ).toFixed(2)
      : "0.00";

    kpis.value.total_fianncial = kpis.value.total_validated_tickets * TICKET_VALUE;

    console.log("Loaded KPIs:", kpis.value);
  } catch (error) {
    console.error("Failed to load KPIs", error);
  } finally {
    kpisLoading.value = false;
  }
};

const loadValidationReport = async () => {
  try {
    const { data } = await api.get("/report/validationReport");
    const report = Array.isArray(data) ? data : data?.data;
    if (Array.isArray(report)) validationReport.value = report;
  } catch (error) {
    console.error("Failed to load validation report", error);
  }
};

const loadFinancialReport = async () => {
  try {
    const { data } = await api.get("/report/financialReport");
    const report = Array.isArray(data) ? data : data?.data;
    if (Array.isArray(report)) {
      sales.value = report.map((item) => ({
        unit: item?.name ?? "",
        tickets: item?.tickets?.total ?? 0,
        verified: item?.tickets?.verified ?? 0,
        verifiedPercent: item?.tickets?.total
          ? ((item.tickets.verified / item.tickets.total) * 100).toFixed(2)
          : "0.00",
        vendors: Array.isArray(item?.vendedores)
          ? item.vendedores.length
          : item?.vendedores ?? 0,
      }));
    }
  } catch (error) {
    console.error("Failed to load financial report", error);
  }
};

const validationChart = computed(() => ({
  labels: validationReport.value.map((item) => item.date),
  datasets: [
    {
      label: "Verificadas",
      data: validationReport.value.map((item) => item.total),
    },
  ],
}));

onMounted(() => {
  loadKpis();
  loadValidationReport();
  loadFinancialReport();
});
</script>
<template>
  <div class="py-4 container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-6 mb-lg">
            <div class="card z-index-2">
              <gradient-line-chart id="chart-line" title="Resumo Validações" :chart="validationChart" />
            </div>
          </div>
          <div class="col-lg-6">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-12">
                <mini-statistics-card title="Cartelas Cadastradas" :value="{ text: kpiValues.totalTickets }"
                  :loading="kpisLoading" description="" :icon="{
                component: 'ni ni-money-coins',
                background: 'bg-gradient-primary',
                shape: 'rounded-circle',
              }" />
              </div>
              <div class="col-lg-6 col-md-6 col-12">
                <mini-statistics-card title="Cartelas Verificadas"
                  :value="{ text: kpiValues.totalValidatedTickets + ' | ' + kpiValues.verifiedPercent + '%' }"
                  :loading="kpisLoading" description="" :icon="{
                component: 'ni ni-check-bold',
                background: 'bg-gradient-danger',
                shape: 'rounded-circle',
              }" />
              </div>
              <div class="col-lg-6 col-md-6 col-12">
                <mini-statistics-card title="Vendedores Cadastrados" :value="{ text: kpiValues.totalVendors }"
                  :loading="kpisLoading" description="" :icon="{
                component: 'ni ni-paper-diploma',
                background: 'bg-gradient-success',
                shape: 'rounded-circle',
              }" />
              </div>
              <div class="col-lg-6 col-md-6 col-12">
                <mini-statistics-card title="Arrecadado" :value="{ text: kpiValues.totalFinancial }"
                  :loading="kpisLoading" description="" :icon="{
                component: 'ni ni-cart',
                background: 'bg-gradient-warning',
                shape: 'rounded-circle',
              }" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
